from flask import Flask, request, jsonify, render_template
import joblib

app = Flask(__name__)

# Carregar o modelo treinado
model = joblib.load('teste\odelo_treinado.joblib')

@app.route('/lelo', methods=['POST'])
def test():
    return ("testar api, aprovado")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Obter os dados do formulário
    nome = request.form['nome']
    idade = int(request.form['idade'])
    classe = request.form['classe']
    hours = float(request.form['hours'])
    
    # Fazer a previsão usando o modelo
    prediction = model.predict([[hours]])
    predicted_score = round(float(prediction[0]), 2)
    
    # Construir a resposta
    if predicted_score < 50.0:
        mensagem = (f"Caro estudante {nome}, se estudar {hours} horas por dia, "
                    f"provavelmente a percentagem de acretividade sera de {predicted_score}%. "
                    "Estude mais para conseguir alcançar uma percentagem satisfatória.")
    else:
        mensagem = (f"Caro estudante {nome}, se estudar {hours} horas por dia, "
                    f"provavelmente a percentagem de acertividade será de {predicted_score}%.")
    
    return jsonify({'mensagem': mensagem})

if __name__ == '__main__':
    app.run(debug=True)
