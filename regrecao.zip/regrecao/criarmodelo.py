import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import joblib
import seaborn as sns

data = pd.read_csv('score_updated.csv')

data.head(10)
data.describe()

X = data.drop(columns=['Scores'], axis=1)  # X contains the feature columns, excluding 'Scores'
y = data.drop(columns=['Hours'], axis=1)   # y contains the target variable 'Scores', excluding 'Hours'

# Definimos el dataset entre set de entrenamiento y set de prueba
X_train, X_test, y_train, y_test = train_test_split(X.to_numpy(), y, test_size=0.2, random_state=42)

# Utilizamos a função Linear de regrecao e utilizamos 
model = LinearRegression()  # Definición del modelo
model.fit(X_train, y_train)  # Entrenamiento del modelo

y_pred = model.predict(X_train)

y_pred = model.predict(X_test)  

# notas_predichas = model.predict([[5]])
# print("Notas de un alumno que estudió x horas: ", notas_predichas)

#Treina o modelo
model.fit(X_train, y_train)

# Grava o modelo em um arquivo
joblib.dump(model, 'odelo_treinado.joblib')